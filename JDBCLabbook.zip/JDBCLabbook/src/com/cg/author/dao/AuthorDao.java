package com.cg.author.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import com.cg.author.bean.AuthorBean;

public class AuthorDao {

	Connection conn = null;
	PreparedStatement ps = null;
	int rows = 0;
	GetConnection gc = new GetConnection();
	
	public int addAuthor(AuthorBean beanObj) {
	try {
		conn = gc.getConn();
		String sql = "insert into author values(?,?,?,?,?)";
		ps = conn.prepareStatement(sql);
		ps.setInt(1,beanObj.getAuthorId());
		ps.setString(2, beanObj.getFirstName());
		ps.setString(3, beanObj.getMiddleName());
		ps.setString(4, beanObj.getLastName());
		ps.setLong(5, beanObj.getPhoneNo());
		rows = ps.executeUpdate();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	finally {
		if(conn!=null) {
			try {
				ps.close();
				conn.close();
			} catch (SQLException e) {
				
			}
			
		}
	}
		return rows;
	}
	
	public int updateAuthor(Integer authorId,Long phoneNo) {
		try {
			conn = gc.getConn();
			String sql = "update author set phoneNo=? where authorId=?";
			ps = conn.prepareStatement(sql);
			ps.setLong(1,phoneNo);
			ps.setInt(2,authorId);
			rows = ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			if(conn!=null) {
				try {
					ps.close();
					conn.close();
				} catch (SQLException e) {
					
				}
				
			}
		}
			return rows;
		}
	
	public int deleteAuthor(Integer authorId) {
		try {
			conn = gc.getConn();
			String sql = "delete from author where authorId=?";
			ps = conn.prepareStatement(sql);
			ps.setLong(1,authorId);
			rows = ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			if(conn!=null) {
				try {
					ps.close();
					conn.close();
				} catch (SQLException e) {
					
				}
				
			}
		}
			return rows;
		}
	
	
}
