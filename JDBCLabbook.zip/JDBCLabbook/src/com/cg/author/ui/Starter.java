package com.cg.author.ui;

import java.util.Scanner;

import com.cg.author.bean.AuthorBean;
import com.cg.author.service.AuthorService;

public class Starter {

	@SuppressWarnings("resource")
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		AuthorBean beanObj = new AuthorBean();
		AuthorService serviceObj = new AuthorService();
		char ch = 'y';
		while(ch!='n') {
			System.out.println("Enter 1 to insert");
			System.out.println("Enter 2 to update");
			System.out.println("Enter 3 to delete");
			System.out.println("Enter 4 to view details");
			System.out.println("Enter your choice");
			int choice = sc.nextInt();
			Integer authorId;
			String firstName;
			String middleName;
			String lastName;
			Long phoneNo;
			int rows;
			
			switch(choice) {
			case 1:
				System.out.println("Enter author id");
				authorId = sc.nextInt();
				beanObj.setAuthorId(authorId);
				System.out.println("Enter author first name");
				firstName = sc.next();
				beanObj.setFirstName(firstName);
				System.out.println("Enter author middle name");
				middleName = sc.next();
				beanObj.setMiddleName(middleName);
				System.out.println("Enter author last name");
				lastName = sc.next();
				beanObj.setLastName(lastName);
				System.out.println("Enter author phone number");
				phoneNo = sc.nextLong();
				beanObj.setPhoneNo(phoneNo);
				rows = serviceObj.insertAuthor(beanObj);
				System.out.println(rows+" rows inserted");
				
				break;
			case 2:
				System.out.println("Enter author id whose details you want to update");
				authorId = sc.nextInt();
				System.out.println("Enter new mobile number");
				phoneNo = sc.nextLong();
				rows = serviceObj.updateAuthor(authorId,phoneNo);
				System.out.println(rows+" rows updated");
				break;
			case 3:
				System.out.println("Enter author id whose details you want to delete");
				authorId = sc.nextInt();
				rows = serviceObj.deleteAuthor(authorId);
				System.out.println(rows+" rows deleted");
				break;
			case 4:
				System.out.println("Enter author id whose details you want to view");
				authorId = sc.nextInt();
				= serviceObj.viewAuthor(authorId);
				System.out.println(rows+" rows deleted");
				break;
			default:
				System.out.println("Invalid choice");
			}
			System.out.println("Do you want to continue? y or no");
			ch = sc.next().charAt(0);
		}
		
	}
}
